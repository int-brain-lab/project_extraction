# check that samuel_cuedBiasedChoiceWorld runs as intended
# 1. verify time delay between audio cue and stimOn is ~equal to the INTERACTIVE_DELAY specified
# 2. verify that the readout from rotary encoder is uninterrupted?
# 3. anything else?